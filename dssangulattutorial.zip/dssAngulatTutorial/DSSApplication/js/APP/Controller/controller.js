application.controller('customer', function ($scope) {
	 
	 $scope.message="welcomeTo customer";
	 $scope.options = {width: 500, height: 300, 'bar': 'aaa'};
     $scope.data = [1, 2, 3, 4];
     $scope.hovered = function(d){
         $scope.barValue = d;
         $scope.$apply();
     };
     $scope.barValue = 'None';
	 
 });
  
application.controller('people', function ($scope) {
		 
		 $scope.message="welcomeTo people";	 
	 });

application.controller('Competency', function ($scope) {
	 
	 $scope.message="welcomeTo competency";
	 $scope.data = [[[0, 1], [1, 5], [2, 2]]];
	 
});


application.controller('DeliveryExcellence', function ($scope) {
	
	 $scope.message="welcomeTo deliveryExcellence";	 
	 var daftPoints = [[0, 4]],
	    punkPoints = [[1, 20]];
 
       var data1 = [
     {
         data: daftPoints,
         color: '#00b9d7',
         bars: {show: true, barWidth:1, fillColor: '#00b9d7', order: 1, align: "center" }
     },
     {
         data: punkPoints,
         color: '#3a4452',
         bars: {show: true, barWidth:1, fillColor: '#3a4452', order: 2, align: "center" }
     }
 ];      
 
 $scope.data = data1;
	 
});