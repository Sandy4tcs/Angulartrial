 var application=angular.module('DSSApplication', ['ui.router']);
 
  application.config(function($stateProvider, $urlRouterProvider){
    
    // For any unmatched url, send to /route1
    $urlRouterProvider.otherwise("/route1")
    
    $stateProvider
      .state('route1', {
          url: "/route1",
          templateUrl: "partials/Customer.html",
          controller: 'customer'
      })
      .state('route2', {
            url: "/route2",
            templateUrl: "charts.html",
            controller: 'people'
                
        })
         .state('route3', {
            url: "/route3",
            templateUrl: "partials/Competency.html",
            controller: 'Competency'
        })
         .state('route4', {
            url: "/route4",
            templateUrl: "partials/DeliveryExcellence.html",
            controller: 'DeliveryExcellence'
            
        })       
  })
  

