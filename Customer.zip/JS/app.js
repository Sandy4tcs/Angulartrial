var app=angular.module('myCustomer',[]);
app.controller('myController',function($scope){
	$scope.names = [
    {name:'Jani',country:'Norway',orders:'8'},
    {name:'Carl',country:'Sweden',orders:'18'},
    {name:'Margareth',country:'England',orders:'28'},
    {name:'Hege',country:'Norway',orders:'34'},
    {name:'Joe',country:'Denmark',orders:'25'},
    {name:'Gustav',country:'Sweden',orders:'12'},
    {name:'Birgit',country:'Denmark',orders:'6'},
    {name:'Mary',country:'England',orders:'8'},
    {name:'Kai',country:'Norway',orders:'14'}
  ];
});